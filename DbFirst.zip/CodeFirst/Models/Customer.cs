﻿using System;
using System.Collections.Generic;

namespace DbFirstApp.Models
{
    public partial class Customer
    {
        public int? Id { get; set; }
        public string? Fname { get; set; }
    }
}
