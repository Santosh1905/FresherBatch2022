﻿using System;
using System.Collections.Generic;

namespace DbFirstApp.Models
{
    public partial class Empdetail
    {
        public int Id { get; set; }
        public string? Ename { get; set; }
        public decimal? Salary { get; set; }
    }
}
