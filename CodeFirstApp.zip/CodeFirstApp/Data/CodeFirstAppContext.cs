﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CodeFirstApp.Model;

namespace CodeFirstApp.Data
{
    public class CodeFirstAppContext : DbContext
    {
        public CodeFirstAppContext (DbContextOptions<CodeFirstAppContext> options)
            : base(options)
        {
        }

        public DbSet<CodeFirstApp.Model.Cypto> Cypto { get; set; }
    }
}
