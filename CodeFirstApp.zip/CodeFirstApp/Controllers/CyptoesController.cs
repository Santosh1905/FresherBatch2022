﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CodeFirstApp.Data;
using CodeFirstApp.Model;

namespace CodeFirstApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CyptoesController : ControllerBase
    {
        private readonly CodeFirstAppContext _context;

        public CyptoesController(CodeFirstAppContext context)
        {
            _context = context;
        }

        // GET: api/Cyptoes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Cypto>>> GetCypto()
        {
            return await _context.Cypto.ToListAsync();
        }

        // GET: api/Cyptoes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Cypto>> GetCypto(int id)
        {
            var cypto = await _context.Cypto.FindAsync(id);

            if (cypto == null)
            {
                return NotFound();
            }

            return cypto;
        }

        // PUT: api/Cyptoes/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCypto(int id, Cypto cypto)
        {
            if (id != cypto.Id)
            {
                return BadRequest();
            }

            _context.Entry(cypto).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CyptoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Cyptoes
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Cypto>> PostCypto(Cypto cypto)
        {
            _context.Cypto.Add(cypto);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCypto", new { id = cypto.Id }, cypto);
        }

        // DELETE: api/Cyptoes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCypto(int id)
        {
            var cypto = await _context.Cypto.FindAsync(id);
            if (cypto == null)
            {
                return NotFound();
            }

            _context.Cypto.Remove(cypto);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool CyptoExists(int id)
        {
            return _context.Cypto.Any(e => e.Id == id);
        }
    }
}
