﻿namespace CodeFirstApp.Model
{
    public class Cypto
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public int price { get; set; }
    }
}
