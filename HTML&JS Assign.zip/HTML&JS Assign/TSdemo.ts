function DoCal(a:number,b:number,c:number)
{
    return (a*b) + c;
}
var res = DoCal(3,2,1);
console.log(res);