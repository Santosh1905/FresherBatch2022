﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace AdoCrud
{

    class Program
    {
        static void Main(string[] args)
        {
            callmethod();
            Console.ReadLine();
        }
        public static void callmethod()
        {
            SqlConnection con = null;
            //string connectionstring = ConfigurationManager.ConnectionStrings["dbconnectionstring"].ConnectionString;
            string connectionstring = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=master;Data Source=LAPTOP-LQJ9O5D2";
            string tr;
            do
            {
                Console.WriteLine("Enter your choice: 1.create table 2. Insert 3. Retrieve 4.Update 5.Delete");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {

                    case 1:
                        using (con = new SqlConnection(connectionstring))
                        {
                            SqlCommand createtable = new SqlCommand("Create table empdetails(id int , ename varchar(20), salary decimal(10,2))", con);
                            con.Open();
                            createtable.ExecuteNonQuery();
                            Console.WriteLine(" Table created");
                        }
                        break;

                    case 2:
                        using (con = new SqlConnection(connectionstring))
                        {
                            Console.Write(" Enter the id to insert : ");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine();
                            Console.Write(" Enter the name  to insert : ");
                            string ename1 = Console.ReadLine();
                            Console.WriteLine();
                            Console.Write(" Enter the salary to insert : ");
                            double salary = Convert.ToDouble(Console.ReadLine());
                            SqlCommand insertquery = new SqlCommand(" insert into empdetails(id, ename, salary) values(" + id + ",' " + ename1 + " ', " + salary + ")", con);
                            con.Open();
                            insertquery.ExecuteNonQuery();
                            Console.WriteLine(" Record inserted successfully");
                        }
                        break;
                    case 3:
                        try
                        {
                            con = new SqlConnection(connectionstring);
                            SqlCommand cmd = new SqlCommand("select * from empdetails", con);
                            con.Open();
                            SqlDataReader str = cmd.ExecuteReader();
                            while (str.Read())
                            {
                                Console.WriteLine(str["id"] + " " + str["ename"] + " " + str["salary"]);
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine("Exception" + e);
                        }
                        finally
                        {
                            con.Close();
                            Console.WriteLine("connection closed");
                        }

                        break;

                    case 4:
                        using (con = new SqlConnection(connectionstring))
                        {
                            Console.Write("Enter id:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine();
                            Console.Write($"Enter salary based on id = {id}:");
                            double salary = Convert.ToDouble(Console.ReadLine());
                            SqlCommand Updatequery = new SqlCommand("Update empdetails SET salary=" + salary + " WHERE id=" + id + " ", con);
                            con.Open();
                            int Updateddetails = Updatequery.ExecuteNonQuery();
                            Console.WriteLine("no.of rows affected" + Updateddetails);
                        }
                        break;

                    case 5:
                        using (con = new SqlConnection(connectionstring))
                        {
                            Console.Write("Enter an ID to delete employee of that particular person:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            SqlCommand Deletequery = new SqlCommand("Delete from empdetails where id=" + id + " ", con);
                            con.Open();
                            Deletequery.ExecuteNonQuery();
                            Console.WriteLine($"The Id : {id} of this Record deleted successfully");
                        }
                        break;

                    default:
                        Console.WriteLine("Please Enter values as shown in above range choice");
                        break;
                }
                Console.WriteLine("Do you Want to Continue: yes/no:");
                tr = Console.ReadLine();
            } while (tr != "no");



        }


    }

}